# SiteBoost — launch-ready web app

SiteBoost is a Flask SaaS starter with a live public-page scanner, free results, account registration/login, saved scan history, subscription pricing UI, and Stripe Checkout wiring.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```
Open http://localhost:5000

## Deploy on Render
1. Put this folder in a GitHub repository.
2. In Render choose **New > Blueprint** and connect the repository. `render.yaml` supplies the web service and persistent disk configuration.
3. Add the Stripe environment variables from `.env.example` if you want checkout to work.
4. Attach your custom domain in Render after the service is live.

## Stripe setup
Create recurring monthly products for Starter ($19), Pro ($49), and Business ($99). Copy each Stripe Price ID into the matching environment variable.

The `/api/checkout` route creates a real Stripe Checkout Session when the keys are present. Before charging customers, add a Stripe webhook for `checkout.session.completed`, subscription changes, and cancellations so the `users.plan` value stays synchronized.

## Before public launch
- Add Terms of Service, Privacy Policy, Refund/Cancellation Policy, and support contact details.
- Add email verification and password reset.
- Add rate limiting and abuse protection to the scan endpoint.
- Add Stripe webhook handling and customer billing portal.
- Move from SQLite to managed PostgreSQL when traffic grows.
- Review analytics/cookie consent requirements for the jurisdictions you serve.

## Important product claim
SiteBoost's score is an internal diagnostic score. It is not a Google ranking, a guarantee of search placement, or a guarantee of business revenue.
