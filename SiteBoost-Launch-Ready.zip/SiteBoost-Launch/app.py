import os, re, sqlite3, socket, ipaddress, secrets
from functools import wraps
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify, session, redirect
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
DB = os.environ.get('DATABASE_PATH','siteboost.db')

PLANS = {
    'starter': {'name':'Starter','price':19,'env':'STRIPE_PRICE_STARTER'},
    'pro': {'name':'Pro','price':49,'env':'STRIPE_PRICE_PRO'},
    'business': {'name':'Business','price':99,'env':'STRIPE_PRICE_BUSINESS'},
}

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      plan TEXT DEFAULT 'free',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS scans(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      url TEXT, brand TEXT, score INTEGER, title TEXT, description TEXT,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS campaigns(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      brand TEXT, goal TEXT, authority TEXT, articles INTEGER,
      budget INTEGER, status TEXT DEFAULT 'Planning',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    ''')
    c.commit(); c.close()
init_db()

def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if not session.get('uid'):
            return jsonify({'ok':False,'error':'Please log in first.'}),401
        return fn(*a,**kw)
    return wrapped

def normalize_url(u):
    u=(u or '').strip()
    if not re.match(r'^https?://',u,re.I): u='https://'+u
    return u

def safe_public_url(u):
    p=urlparse(u)
    if p.scheme not in ('http','https') or not p.hostname:
        return False
    try:
        for info in socket.getaddrinfo(p.hostname, None):
            ip=ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
    except Exception:
        return False
    return True

def brand_from_url(u):
    host=urlparse(u).netloc.lower().replace('www.','')
    root=host.split('.')[0].replace('-',' ')
    return root.title() or 'Your Brand'

def scan_site(raw):
    u=normalize_url(raw)
    if not safe_public_url(u):
        return {'ok':False,'error':'Please enter a public website URL.'}
    brand=brand_from_url(u)
    try:
        r=requests.get(u,timeout=12,allow_redirects=True,headers={'User-Agent':'Mozilla/5.0 SiteBoostBot/1.0'})
        ct=r.headers.get('content-type','')
        if 'text/html' not in ct: return {'ok':False,'error':'That URL did not return a normal web page.'}
        soup=BeautifulSoup(r.text[:2000000],'html.parser')
        title=(soup.title.string.strip() if soup.title and soup.title.string else brand)
        md=soup.find('meta',attrs={'name':re.compile('^description$',re.I)})
        desc=(md.get('content','').strip() if md else '')
        h1=len(soup.find_all('h1')); h2=len(soup.find_all('h2'))
        links=len(soup.find_all('a')); imgs=soup.find_all('img')
        alt=sum(1 for i in imgs if i.get('alt','').strip())
        text=' '.join(soup.stripped_strings)
        words=len(text.split())
        og=bool(soup.find('meta',property='og:title'))
        canonical=bool(soup.find('link',rel=lambda v: v and 'canonical' in v if isinstance(v,str) else False))
        viewport=bool(soup.find('meta',attrs={'name':'viewport'}))
        score=30 + (10 if r.status_code<400 else -20)
        score += 10 if 25<=len(title)<=70 else 4
        score += 10 if 70<=len(desc)<=180 else (3 if desc else 0)
        score += 6 if h1==1 else (3 if h1>1 else 0)
        score += min(8,h2)
        score += 8 if words>=500 else min(6,max(0,words//75))
        score += 5 if links>=8 else 2
        score += 4 if og else 0; score += 4 if canonical else 0; score += 4 if viewport else 0
        if imgs: score += min(4,round(4*alt/len(imgs)))
        score=max(8,min(96,score))
        opportunities=[]
        if not desc: opportunities.append({'priority':'High','title':'Add a strong meta description','why':'Your search snippet may not clearly explain why someone should click.'})
        elif not 70<=len(desc)<=180: opportunities.append({'priority':'Medium','title':'Tighten the meta description','why':'Keep it concise, specific, and focused on the page value.'})
        if h1==0: opportunities.append({'priority':'High','title':'Add one clear H1','why':'Make the primary topic obvious to visitors and search engines.'})
        if h1>1: opportunities.append({'priority':'Medium','title':'Simplify H1 structure','why':'Use one strong primary heading and supporting H2 sections.'})
        if words<500: opportunities.append({'priority':'Medium','title':'Expand useful page copy','why':'Answer customer questions with more specific, trustworthy information.'})
        if not viewport: opportunities.append({'priority':'High','title':'Add mobile viewport settings','why':'Mobile presentation is a basic usability and search requirement.'})
        if not og: opportunities.append({'priority':'Low','title':'Add social sharing metadata','why':'Control how your pages appear when shared.'})
        if imgs and alt<len(imgs): opportunities.append({'priority':'Low','title':'Improve image alt text','why':'Alt text improves accessibility and topical context.'})
        if not canonical: opportunities.append({'priority':'Low','title':'Add a canonical URL','why':'Clarify the preferred URL version for search engines.'})
        if not opportunities: opportunities=[{'priority':'Medium','title':'Build third-party authority','why':'Earn relevant mentions, links, interviews, and expert citations.'}]
        strengths=[]
        if desc: strengths.append('Meta description detected')
        if viewport: strengths.append('Mobile viewport configured')
        if og: strengths.append('Social sharing metadata detected')
        if words>=500: strengths.append('Substantial on-page copy')
        if h1==1: strengths.append('Clear primary page heading')
        return {'ok':True,'url':u,'brand':brand,'title':title,'description':desc,'score':score,'words':words,'links':links,'strengths':strengths[:5],'opportunities':opportunities[:6]}
    except Exception:
        return {'ok':False,'error':'SiteBoost could not reach that website. Check the address and try again.'}

@app.get('/')
def home(): return render_template('index.html', user_email=session.get('email'))

@app.post('/api/register')
def register():
    x=request.get_json(silent=True) or {}; email=(x.get('email') or '').strip().lower(); pw=x.get('password') or ''
    if '@' not in email or len(pw)<8: return jsonify({'ok':False,'error':'Use a valid email and a password with at least 8 characters.'}),400
    try:
        c=db(); cur=c.execute('INSERT INTO users(email,password_hash) VALUES(?,?)',(email,generate_password_hash(pw))); c.commit(); uid=cur.lastrowid; c.close()
    except sqlite3.IntegrityError:
        return jsonify({'ok':False,'error':'An account already exists for that email.'}),409
    session['uid']=uid; session['email']=email
    return jsonify({'ok':True})

@app.post('/api/login')
def login():
    x=request.get_json(silent=True) or {}; email=(x.get('email') or '').strip().lower(); pw=x.get('password') or ''
    c=db(); u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone(); c.close()
    if not u or not check_password_hash(u['password_hash'],pw): return jsonify({'ok':False,'error':'Email or password is incorrect.'}),401
    session['uid']=u['id']; session['email']=u['email']; return jsonify({'ok':True})

@app.post('/api/logout')
def logout(): session.clear(); return jsonify({'ok':True})

@app.post('/api/scan')
def api_scan():
    x=request.get_json(silent=True) or {}; result=scan_site(x.get('url',''))
    if result.get('ok'):
        import json
        c=db(); c.execute('INSERT INTO scans(user_id,url,brand,score,title,description,details) VALUES(?,?,?,?,?,?,?)',(session.get('uid'),result['url'],result['brand'],result['score'],result['title'],result['description'],json.dumps(result))); c.commit(); c.close()
    return jsonify(result), (200 if result.get('ok') else 400)

@app.get('/api/dashboard')
@login_required
def dashboard():
    c=db(); scans=[dict(x) for x in c.execute('SELECT id,url,brand,score,created_at FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 12',(session['uid'],))]; camps=[dict(x) for x in c.execute('SELECT * FROM campaigns WHERE user_id=? ORDER BY id DESC LIMIT 12',(session['uid'],))]; user=dict(c.execute('SELECT id,email,plan,created_at FROM users WHERE id=?',(session['uid'],)).fetchone()); c.close()
    return jsonify({'ok':True,'user':user,'scans':scans,'campaigns':camps})

@app.post('/api/campaigns')
@login_required
def campaigns():
    x=request.get_json(silent=True) or {}; articles=max(1,min(20,int(x.get('articles',3)))); authority=x.get('authority','Balanced'); base={'Emerging':39,'Balanced':79,'Premium':149}.get(authority,79); budget=articles*base
    c=db(); cur=c.execute('INSERT INTO campaigns(user_id,brand,goal,authority,articles,budget) VALUES(?,?,?,?,?,?)',(session['uid'],x.get('brand','Your Brand'),x.get('goal','Brand Awareness'),authority,articles,budget)); c.commit(); cid=cur.lastrowid; c.close()
    return jsonify({'ok':True,'id':cid,'budget':budget})

@app.post('/api/checkout')
@login_required
def checkout():
    x=request.get_json(silent=True) or {}; plan=(x.get('plan') or '').lower()
    if plan not in PLANS: return jsonify({'ok':False,'error':'Unknown plan.'}),400
    secret=os.environ.get('STRIPE_SECRET_KEY'); price=os.environ.get(PLANS[plan]['env'])
    if not secret or not price:
        return jsonify({'ok':False,'error':'Payments are not connected yet. Add your Stripe keys in the hosting environment.'}),503
    base=request.host_url.rstrip('/')
    data=[('mode','subscription'),('success_url',base+'/?checkout=success'),('cancel_url',base+'/#pricing'),('line_items[0][price]',price),('line_items[0][quantity]','1'),('client_reference_id',str(session['uid'])),('customer_email',session['email'])]
    r=requests.post('https://api.stripe.com/v1/checkout/sessions',data=data,auth=(secret,''),timeout=15)
    if r.status_code>=400: return jsonify({'ok':False,'error':'Stripe could not create checkout.'}),502
    return jsonify({'ok':True,'url':r.json()['url']})

@app.get('/health')
def health(): return {'ok':True,'app':'SiteBoost'}

if __name__=='__main__':
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5000')),debug=True)
